package com.example.commition;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText edt_tot_amt,edt_per;
String str_tot,str_per;
Button btn_calc;
TextView txt_tamt,txt_samt,txt_ramt;
double dt,dp,dr,commission;
Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);

        //------------------------Toolbar-------------------------------------------
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        TextView toolbar_title = (TextView) toolbar.findViewById(R.id.toolbar_title);//title
        ImageView toolbar_img = (ImageView) toolbar.findViewById(R.id.toolbar_refresh);//title
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        toolbar.setTitleTextColor(0xFFFFFFFF);
        toolbar_title.setText("Commission Calculator");
        toolbar_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                startActivity(getIntent());
            }
        });

        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        }

        edt_tot_amt=(EditText)findViewById(R.id.edt_tot_amt);
        edt_per=(EditText)findViewById(R.id.edt_per);
        txt_tamt=(TextView)findViewById(R.id.txt_tamt);
        txt_samt=(TextView)findViewById(R.id.txt_samt);
        txt_ramt=(TextView)findViewById(R.id.txt_ramt);
        btn_calc=(Button)findViewById(R.id.btn_calc);
        btn_calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                str_tot=edt_tot_amt.getText().toString();
                if(str_tot.equals(""))
                {
                    Toast.makeText(MainActivity.this, "Field can not be null", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    dt=Double.parseDouble(str_tot);
                }
                str_per=edt_per.getText().toString();
                if(str_per.equals(""))
                {
                    Toast.makeText(MainActivity.this, "Field can not be null", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    dp=Double.parseDouble(str_per);
                }

                 commission=(dp/100)*dt;
                dr=dt-commission;

                txt_tamt.setText(""+dt);
                txt_samt.setText(""+commission);
                txt_ramt.setText(""+dr);

            }
        });
    }
}
